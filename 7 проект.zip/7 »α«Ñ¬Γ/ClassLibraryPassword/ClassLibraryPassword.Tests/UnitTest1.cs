
using ClassLibraryPassword;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ClassLibraryPassword.Tests
{
    
    public class PasswordCheckerTests
    {
        [TestMethod()]
        public void Check_85mbols_ReturnTrue()
        {
            // Arrange.
            string password = "ASqw12$$";
            bool expected = true;

            // Act.
            bool actual = PasswordChecker.ValidatePassword(password);

            // Assert.
            Assert.AreEqual(expected, actual);
        }
/*        [TestMethod()]
        public void Check_4Symbols_ReturnFalse()
        {
            // Arrange.
            string password =
        }*/
    }
}